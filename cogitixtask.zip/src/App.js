import EpisodeSidebar from "./component/EpisodeSidebar";

function App() {
  return (
    <div>
      <EpisodeSidebar />
    </div>
  );
}

export default App;
